#include "Scene.h"

CScene::CScene()
{

}

CScene::~CScene()
{

}

void CScene::Awake()
{

}

void CScene::Start()
{

}

void CScene::Update()
{

}

void CScene::Destroy()
{

}

void CScene::Render(ID2D1HwndRenderTarget* _pRT)
{

}